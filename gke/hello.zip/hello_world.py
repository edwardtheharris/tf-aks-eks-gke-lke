#!/usr/bin/env python3
"""This module contains the hello world function."""

def hello_world():
    """Print hello world."""
    result = "Hello, world!"

    print(result)

    return result


if __name__ == '__main__':
    hello_world()
